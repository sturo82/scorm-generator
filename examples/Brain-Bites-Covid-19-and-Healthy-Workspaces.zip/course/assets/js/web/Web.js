var Web = {
	
	getStructure: function() {

		var obj = new Object();
		obj.Lesson_location = parent.Lesson_location;
		obj.PageVisitedStatus = parent.PageVisitedStatus;
		console.log(parent.structure);

		Navigation.loadStructure(parent.structure, obj);
		//Navigation.navigation(obj);
		/*var file = bridgeURL +'?id=prabaharan.sachin1@gmail.com&name=prabaharan.sachin1@gmail.com&course=' + courseId + '&reseller=' + resellerName;
		$.getJSON(file, function(data) {
			console.log(data);		
			//alert(data.result.code);
			if(data.result.code == "1"){
				data.result.structure.interfaceText = data.result.interfaceText;
				const converted = Utils.toBinary(JSON.stringify(data.result.structure));
				window.localStorage.setItem("structure" + courseId, window.btoa(converted));
				Navigation.loaStructure(data.result.structure, 'obj = Web.get()');
				
			}else{
				$('#info').html(data.result.message+', please contact <a href="mailto:sales@bigger-brains.com"> sales@bigger-brains.com</a>');
				$('#reseller_popup').show();
			}
			
		})
		.fail(function() {
			let today = new Date().toLocaleDateString();
			var lastDateAccessee = localStorage.getItem("dateAccessed" + courseId);
			if(lastDateAccessee != null && lastDateAccessee != undefined && lastDateAccessee != '') {
				
				const date1 = new Date(today);
				const date2 = new Date(lastDateAccessee);
				const diffTime = Math.abs(date2 - date1);
				const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
				if(diffDays > 3) {
					$('#info').html('Communication Problem!, please contact <a href="mailto:sales@bigger-brains.com"> sales@bigger-brains.com</a>');
					$('#reseller_popup').show();
					return false;
				} 
			} else {
				window.localStorage.setItem("dateAccessed" + courseId, today);
			}
			const decoded = window.atob(localStorage.getItem("structure" + courseId));
			const original = Utils.fromBinary(decoded);
			Navigation.loaStructure(JSON.parse(original), 'obj = Web.get()');
		});*/
	},
	get:function(){
		var lesson_location_cookie = "lesson_location" + Framework.courseId;
		var pagevisisted_cookie = "pagevisitedstatus" + Framework.courseId;
		var obj = new Object();
		obj.Lesson_location = readCookie(lesson_location_cookie);
		obj.PageVisitedStatus = readCookie(pagevisisted_cookie);
		Navigation.navigation(obj);
	},
	
	set:function(Lesson_location, PageVisitedStatus){
		
		var lesson_location_cookie = "lesson_location" + Framework.courseId;
		var pagevisisted_cookie = "pagevisitedstatus" + Framework.courseId;
		createCookie(lesson_location_cookie,Lesson_location,100);
		createCookie(pagevisisted_cookie,PageVisitedStatus,100);
	}
}